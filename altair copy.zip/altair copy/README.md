# Altair docs

## Make sure that the submodule is cloned 
  * git clone --recurse-submodules git@sig-gitlab.internal.synopsys.com:doc/altair.git
  * git pull --recurse-submodules


You need to do this to get the docs-dita-tools into the correct path for the makefile to work.

To build html and copy the output to the altair-kong-dev-portal repository:
	* make clean
	* make html
	* make copy

